public class QuickSort extends SortAlgorithm {

	public QuickSort(int input_array[]) {
		super(input_array);
	}
	
    private int partition(???){
        // fill this method
    }

    private void sort(???){
        // fill this method
    }

    @Override
    public void sort() {
    	sort(???);
    }

    @Override
    public void print() {
    	System.out.print("Quick Sort\t=>\t");
    	super.print();
    }
}
