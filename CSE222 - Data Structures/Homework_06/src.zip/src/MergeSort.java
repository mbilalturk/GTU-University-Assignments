public class MergeSort extends SortAlgorithm {
	
	public MergeSort(int input_array[]) {
		super(input_array);
	}
	
	private void merge(???){
        // fill this method
    }

    private void sort(???){
        // fill this method
    }
    
    @Override
    public void sort() {
    	sort(???);
    }
    
    @Override
    public void print() {
    	System.out.print("Merge Sort\t=>\t");
    	super.print();
    }
}
